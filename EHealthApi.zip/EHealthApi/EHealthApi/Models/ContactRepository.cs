﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EHealthApi.Models
{
    public class ContactRepository : IContactRepository
    {
        private static ConcurrentDictionary<string, Contact> _contactCollection =
              new ConcurrentDictionary<string, Contact>();
        public ContactRepository()
        {
            Add(new Contact { FirstName = "Sam",LastName="Billing",Email="sam.billing@hotmail.com",PhoneNumber=98777729,Status="Active" });
        }

        public void Add(Contact item)
        {
            item.ContactId = Guid.NewGuid().ToString();
            _contactCollection[item.ContactId] = item;
        }
        /// <summary>
        /// This will add new contact
        /// </summary>
        /// <param name="_contact"></param>
        public void AddContact(Contact _contact)
        {
            _contact.ContactId = Guid.NewGuid().ToString();
            _contactCollection[_contact.ContactId] = _contact;
        }
        /// <summary>
        /// This will delete the particular record
        /// </summary>
        /// <param name="contactId"></param>
        /// <returns></returns>

        public Contact DeleteContact(string contactId)
        {
            Contact item;
            _contactCollection.TryGetValue(contactId, out item);
            _contactCollection.TryRemove(contactId, out item);
            return item;
        }

        /// <summary>
        /// This will give List of all contact
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Contact> GetAllContact()
        {
            return _contactCollection.Values;
        }

        /// <summary>
        /// This will update the contact 
        /// </summary>
        /// <param name="contact"></param>
        public void UpdateContact(Contact contact)
        {
            _contactCollection[contact.ContactId] = contact;
        }

        public Contact Find(string contactId)
        {
            Contact _contact;
            _contactCollection.TryGetValue(contactId, out _contact);
            return _contact;
        }
    }
}
