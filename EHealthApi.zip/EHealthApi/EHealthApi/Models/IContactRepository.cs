﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EHealthApi.Models
{
    public interface IContactRepository
    {
        void AddContact(Contact contact);
        IEnumerable<Contact> GetAllContact();
        void UpdateContact(Contact contact);
        Contact DeleteContact(string contactId);
        Contact Find(String contactId);
    }
}
