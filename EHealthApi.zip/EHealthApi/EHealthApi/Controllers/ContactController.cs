﻿using EHealthApi.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace EHealthApi.Controllers
{
    [Route("api/[controller]")]
    public class ContactController : Controller
    {
        public ContactController(IContactRepository contactRepository)
        {
            ContactRepository = contactRepository;
        }

        public IContactRepository ContactRepository {get;set;}

        [HttpGet]

        public IEnumerable<Contact> ListAllContact()
        {
            return ContactRepository.GetAllContact();
        }

        [HttpGet("{id}", Name = "GetContact")]
        public IActionResult GetById(string id)
        {
            var item = ContactRepository.Find(id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Contact item)
        {
            if (item == null)
            {
                return BadRequest();
            }
            ContactRepository.AddContact(item);
            return CreatedAtRoute("GetContact", new { id = item.ContactId }, item);
        }

        [HttpPut("{id}")]
        public IActionResult Update(string id, [FromBody] Contact item)
        {
            if (item == null || item.ContactId != id)
            {
                return BadRequest();
            }
            var avilableContact = ContactRepository.Find(id);
            if (avilableContact == null)
            {
                return NotFound();
            }

            ContactRepository.UpdateContact(item);
            return new NoContentResult();
        }

        [HttpDelete("{id}")]
        public void Delete(string id)
        {
            ContactRepository.DeleteContact(id);
        }

    }
}
